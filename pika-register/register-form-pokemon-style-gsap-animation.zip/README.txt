A Pen created at CodePen.io. You can find this one at https://codepen.io/choudhary-yash-munjal/pen/pYPErQ.

 